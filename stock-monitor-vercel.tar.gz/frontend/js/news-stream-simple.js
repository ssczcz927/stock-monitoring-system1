// 简化版实时新闻流
class SimpleNewsStream {
    constructor() {
        this.currentPage = 1;
        this.isLoading = false;
        this.newsContainer = null;
        
        // 确保DOM加载完成后初始化
        setTimeout(() => this.init(), 500);
    }

    init() {
        this.newsContainer = document.getElementById('newsContainer');
        if (!this.newsContainer) {
            console.error('新闻容器未找到');
            return;
        }
        
        console.log('初始化简化新闻流...');
        this.loadNews();
        this.setupScrollListener();
    }

    async loadNews() {
        if (this.isLoading) return;
        
        this.isLoading = true;
        this.showLoading(true);
        
        try {
            const response = await fetch(`http://localhost:5001/api/news/flat/${this.currentPage}`);
            const data = await response.json();
            
            const news = data.news || [];
            
            if (this.currentPage === 1) {
                this.newsContainer.innerHTML = '';
            }
            
            news.forEach(item => {
                const card = this.createNewsCard(item);
                this.newsContainer.appendChild(card);
            });
            
            console.log(`已加载${news.length}条新闻`);
            
        } catch (error) {
            console.error('加载新闻失败:', error);
            this.newsContainer.innerHTML = '<div style="text-align: center; padding: 20px; color: red;">加载新闻失败</div>';
        } finally {
            this.isLoading = false;
            this.showLoading(false);
        }
    }

    createNewsCard(news) {
        const card = document.createElement('div');
        card.className = 'news-card-modern clickable-card';
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.3s ease';
        
        const timeAgo = this.formatTime(news.timestamp);
        
        card.innerHTML = `
            <div class="news-content">
                <h3 class="news-title">${news.title}</h3>
                <p class="news-summary">${news.summary}</p>
                <div class="news-meta">
                    <span class="source">${news.source}</span>
                    <span class="time">${timeAgo}</span>
                </div>
            </div>
        `;
        
        card.addEventListener('click', () => {
            if (news.url && news.url !== '#') {
                window.open(news.url, '_blank');
            }
        });
        
        // 添加动画
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100);
        
        return card;
    }

    setupScrollListener() {
        window.addEventListener('scroll', () => {
            if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 100) {
                if (!this.isLoading) {
                    this.currentPage++;
                    this.loadNews();
                }
            }
        });
    }

    setupBackToTop() {
        const backToTopBtn = document.getElementById('backToTop');
        if (!backToTopBtn) return;

        // 滚动事件监听
        let scrollTimeout;
        window.addEventListener('scroll', () => {
            clearTimeout(scrollTimeout);
            scrollTimeout = setTimeout(() => {
                const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                const stockSection = document.querySelector('.stock-prices');
                if (!stockSection) return;
                
                const stockSectionTop = stockSection.offsetTop;
                const stockSectionHeight = stockSection.offsetHeight;
                
                // 当滚动超过股价区域时显示按钮
                if (scrollTop > stockSectionTop + stockSectionHeight) {
                    backToTopBtn.classList.add('show');
                } else {
                    backToTopBtn.classList.remove('show');
                }
            }, 100);
        });

        // 点击回到顶部
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    formatTime(timestamp) {
        const now = Date.now();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        
        if (minutes < 60) return `${minutes}分钟前`;
        return `${hours}小时前`;
    }

    showLoading(show = true) {
        const loadingEl = document.getElementById('loadingMore');
        if (loadingEl) {
            loadingEl.style.display = show ? 'block' : 'none';
        }
    }
}

// 初始化简化版新闻流
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('newsContainer')) {
        window.newsStream = new SimpleNewsStream();
    }
});